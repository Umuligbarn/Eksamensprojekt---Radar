// Ensure the video auto plays when the page loads and starts muted
window.addEventListener('DOMContentLoaded', (event) => {
    const video = document.getElementById('main-video');
    video.muted = true;  // Start muted to fix autoplay issues
    video.play();        // Play the video as soon as it's ready
});

// Mute/Unmute functionality
const volumeCheckbox = document.getElementById('volume-checkbox');
const volumeOn = document.getElementById('volume-on');
const volumeOff = document.getElementById('volume-off');
const video = document.getElementById('main-video');

// Ensure the checkbox updates immediately when clicked
volumeCheckbox.addEventListener('change', function() {
    if (this.checked) {
        // Unmute the video
        video.muted = false;
        volumeOn.style.display = 'block';  // Show the unmute icon
        volumeOff.style.display = 'none'; // Hide the mute icon
    } else {
        // Mute the video
        video.muted = true;
        volumeOn.style.display = 'none';  // Hide the unmute icon
        volumeOff.style.display = 'block'; // Show the mute icon
    }
});

// Burger menu toggle for mobile devices
const burgerToggle = document.getElementById('burger-toggle');
const mobileMenu = document.querySelector('.mobile-menu');

// Toggle mobile menu visibility when burger icon is clicked
burgerToggle.addEventListener('change', function() {
    if (this.checked) {
        mobileMenu.style.display = 'flex'; // Show mobile menu
    } else {
        mobileMenu.style.display = 'none'; // Hide mobile menu
    }
});

// Get the icon element
const scrollIcon = document.querySelector('.scroll-icon');

// Listen for the scroll event
window.addEventListener('scroll', function() {
    // If the page is scrolled more than 50px, hide the icon
    if (window.scrollY > 50) {
        scrollIcon.classList.add('scroll-hidden');
    } else {
        scrollIcon.classList.remove('scroll-hidden');
    }
});


