// Autoplay på video
window.addEventListener("DOMContentLoaded", function (event) {
  const video = document.getElementById("main-video");
  video.muted = true; // Starter muted
  video.play(); // Autoplayer video
});

// Mute/Unmute
const volumeCheckbox = document.getElementById("volume-checkbox");
const volumeOn = document.getElementById("volume-on");
const volumeOff = document.getElementById("volume-off");
const video = document.getElementById("main-video");

volumeCheckbox.addEventListener("change", function () {
  if (this.checked) {
    // Unmute video
    video.muted = false;
    volumeOn.style.display = "block"; // Viser unmute icon
    volumeOff.style.display = "none"; // Skjuler mute icon
  } else {
    // Mute video
    video.muted = true;
    volumeOn.style.display = "none"; // Skjuler unmute icon
    volumeOff.style.display = "block"; // Viser mute icon
  }
});

// Burger menu
const burgerToggle = document.getElementById("burger-toggle");
const mobileMenu = document.querySelector(".mobile-menu");

// Toggle burger menu
burgerToggle.addEventListener("change", function () {
  if (this.checked) {
    mobileMenu.style.display = "flex"; // Viser burger menu
  } else {
    mobileMenu.style.display = "none"; // Skjuler burger menu
  }
});

// Scroll icon
const scrollIcon = document.querySelector(".scroll-icon");

// Scroll event
window.addEventListener("scroll", function () {
  // Forsvinder når man har scrollet 50px
  if (window.scrollY > 50) {
    scrollIcon.classList.add("scroll-hidden");
  } else {
    scrollIcon.classList.remove("scroll-hidden");
  }
});

// Forside banner
const scrollingText = document.getElementById("scrolling-text");

// Sikrer seamless looping
scrollingText.innerHTML += scrollingText.innerHTML;

// Start animation
let offset = 0;
const speed = 1; // Justerer hastighed

function scrollText() {
  offset -= speed;
  scrollingText.style.transform = `translateX(${offset}px)`;

  // Når teksten er scrollet helt ud, nulstil
  if (Math.abs(offset) >= scrollingText.scrollWidth / 2) {
    offset = 0;
  }

  requestAnimationFrame(scrollText);
}

scrollText();
